import java.net.HttpURLConnection
import java.net.URL
import java.util.regex.Pattern
import org.json.JSONObject

// A function that retrieves file data from GitHub API
fun fetchGitHubData(query: String, token: String): String {
    val url = URL("https://api.github.com/search/code?q=$query+language:Java")
    val connection = url.openConnection() as HttpURLConnection
    connection.setRequestProperty("Authorization", "Bearer $token") // using "Bearer" instead of "token"
    connection.requestMethod = "GET"

    return connection.inputStream.bufferedReader().readText()
}


// A function that parses class names from the source code
fun parseClassNamesFromResponse(response: String): List<String> {
    val classNames = mutableListOf<String>()
    val json = JSONObject(response)
    val items = json.getJSONArray("items")

    for (i in 0 until items.length()) {
        val item = items.getJSONObject(i)
        // Can capture file name or other important data
        val fileName = item.getString("name")
        classNames.add(fileName) // Storing the file name or otherwise process
    }

    return classNames
}


// A function that splits class names into words
fun splitClassNameToWords(className: String): List<String> {
    return className.split("(?<!^)(?=[A-Z])".toRegex())
}

// A function that counts the occurrences of words
fun countWordOccurrences(classNames: List<String>): Map<String, Int> {
    val wordCount = mutableMapOf<String, Int>()
    for (name in classNames) {
        for (word in splitClassNameToWords(name)) {
            wordCount[word] = wordCount.getOrDefault(word, 0) + 1
        }
    }
    return wordCount
}

fun main() {
    val token = "TOKEN_NAME" // Enter your token!!!
    val query = "filename:.java"

    // Download data from GitHub API
    val response = fetchGitHubData(query, token)
    //println("Answer from GitHub: $response")

    // Extract class names
    val classNamesFromResponse = parseClassNamesFromResponse(response)
    println("Class names: $classNamesFromResponse")

    // Count occurrences of words in class names
    val wordCount = countWordOccurrences(classNamesFromResponse)
    println("Counted words: $wordCount")

    // Sort words by number of occurrences
    val sortedWords = wordCount.toList().sortedByDescending { it.second }

    // Print top words
    println("Most popular words in class names:")
    for ((word, count) in sortedWords.take(10)) {
        println("$word: $count")
    }
}

